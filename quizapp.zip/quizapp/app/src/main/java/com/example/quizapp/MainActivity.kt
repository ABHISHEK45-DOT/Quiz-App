package com.example.quizapp

import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var questionTextView: TextView
    private lateinit var answersRadioGroup: RadioGroup
    private lateinit var submitButton: Button
    private lateinit var resultTextView: TextView

    private var currentQuestionIndex = 0
    private var score = 0

    private val questions = listOf(
        Question(
            "What is the capital of France?",
            listOf("Berlin", "Madrid", "Paris", "Rome"),
            2
        ),
        Question(
            "Who wrote 'Hamlet'?",
            listOf("Charles Dickens", "William Shakespeare", "J.K. Rowling", "Ernest Hemingway"),
            1
        ),
        Question(
            "What is the largest planet in our Solar System?",
            listOf("Earth", "Mars", "Jupiter", "Saturn"),
            2
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        questionTextView = findViewById(R.id.questionTextView)
        answersRadioGroup = findViewById(R.id.answersRadioGroup)
        submitButton = findViewById(R.id.submitButton)
        resultTextView = findViewById(R.id.resultTextView)

        loadQuestion()

        submitButton.setOnClickListener {
            checkAnswer()
        }
    }

    private fun loadQuestion() {
        val currentQuestion = questions[currentQuestionIndex]
        questionTextView.text = currentQuestion.question
        answersRadioGroup.clearCheck()

        for (i in 0 until answersRadioGroup.childCount) {
            val radioButton = answersRadioGroup.getChildAt(i) as RadioButton
            radioButton.text = currentQuestion.options[i]
        }
    }

    private fun checkAnswer() {
        val selectedRadioButtonId = answersRadioGroup.checkedRadioButtonId
        if (selectedRadioButtonId == -1) {
            Toast.makeText(this, "Please select an answer", Toast.LENGTH_SHORT).show()
            return
        }

        val selectedIndex = answersRadioGroup.indexOfChild(findViewById(selectedRadioButtonId))
        val currentQuestion = questions[currentQuestionIndex]

        if (selectedIndex == currentQuestion.correctAnswerIndex) {
            score++
            resultTextView.text = "Correct!"
        } else {
            resultTextView.text = "Incorrect. The correct answer is ${currentQuestion.options[currentQuestion.correctAnswerIndex]}."
        }

        currentQuestionIndex++

        if (currentQuestionIndex < questions.size) {
            loadQuestion()
        } else {
            showFinalScore()
        }
    }

    private fun showFinalScore() {
        resultTextView.text = "Quiz Finished! Your score is $score/${questions.size}."
        submitButton.isEnabled = false
    }
}
